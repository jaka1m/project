from geo import *
#CEK VMESS
@bot.on(events.NewMessage(pattern=r"(?:start|/start|/start@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def com(event):
	async def com_(event):
		cmd = 'commands'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""{z}
""",buttons=[[Button.inline("‹ 🔙ᴍᴀɪɴ ᴍᴇɴᴜ ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await com_(event)
	else:
		await event.answer("Access Denied",alert=True)
