from geo import *

#AUTO BACKUP 6 JAM
@bot.on(events.CallbackQuery(data=b'enam'))
async def enam(event):
	async def enam_(event):
		cmd = f'printf "%s\n" "3" "1" | settings | sleep 10 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autobackup Every 6 Hour ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobckp")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await enam_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#AUTO BACKUP 12 JAM
@bot.on(events.CallbackQuery(data=b'duabelas'))
async def duabelas(event):
	async def duabelas_(event):
		cmd = f'printf "%s\n" "3" "2" | settings | sleep 10 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autobackup Every 12 Hour ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobckp")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await duabelas_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#AUTO BACKUP 24 JAM
@bot.on(events.CallbackQuery(data=b'duapuluh'))
async def duapuluh(event):
	async def duapuluh_(event):
		cmd = f'printf "%s\n" "3" "3" | settings | sleep 10 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autobackup Every 24 Hour ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobckp")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await duapuluh_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
# OFF AUTO BACKUP
@bot.on(events.CallbackQuery(data=b'turoff'))
async def abackup(event):
	async def abackup_(event):
		cmd = f'printf "%s\n" "3" "4" | settings | sleep 10 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Turn Off Autobackup ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobckp")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await abackup_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
@bot.on(events.NewMessage(pattern=r"(?:.autobckp|/autobckp|autobckp|/autobckp@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'autobckp'))
async def start(event):
	inline = [
[Button.inline(" ᴀꜰᴛᴇʀ 6 ʜᴏᴜʀ ","enam")],
[Button.inline(" ᴀꜰᴛᴇʀ 12 ʜᴏᴜʀ","duabelas"),
Button.inline(" ᴀꜰᴛᴇʀ 24 ʜᴏᴜʀ","duapuluh")],
[Button.inline(" ᴛᴜʀɴ ᴏꜰꜰ","turoff"),
Button.inline("🔙ᴍᴀɪɴ ᴍᴇɴᴜ","backer")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")
		iisp = f" cat /etc/xray/isp"
		iisp = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
•━━━━━━━━━━━━•
**• ꜱᴇᴛᴛɪɴɢ ᴀᴜᴛᴏ ʙᴀᴄᴋᴜᴘ •**
•━━━━━━━━━━━━•
**🔹 ᴏꜱ     :** `{namaos.strip().replace('"','')}`
**🔹 ᴄᴏᴜɴᴛʀʏ :** `{city.strip()}`
**🔹 ʜᴏꜱᴛɴᴀᴍᴇ/ɪᴘ :** `{DOMAIN}`
**🔹 ©ɢᴇᴏ ᴘʀᴏᴊᴇᴄᴛ**
•━━━━━━━━━━━━•
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
