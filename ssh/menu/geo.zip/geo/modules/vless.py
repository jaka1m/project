from geo import *
#CREATE AKUN
@bot.on(events.NewMessage(pattern=r"(?:.addvless|/addvless|addvless|/addvless@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'create-vless'))
async def addvless(event):
	async def addvless_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Username :**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as Quota:
			await event.respond("**Quota :**")
			Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			Quota = (await Quota).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**» Expired (Hari) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as exp2:
			await event.respond("**» Limit User (IP) :**")
			exp2 = exp2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp2 = (await exp2).raw_text
		cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{exp2}" | bot-addvless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			# remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
•━━━━━━━━━━━━•
**• Xray/Vless Account •**
•━━━━━━━━━━━━•
**» `Remarks     :`** `{user}`
**» `Host Server :`** `{DOMAIN}`
**» `User Quota  :`** `{Quota} GB`
**» `User IP      :`** `{exp2} IP`
**» `port TLS    :`** `443-900`
**» `Port NTLS   :`** `80`
**» `Port Grpc   :`** `443`
**» `NetWork     :`** `(WS) or (gRPC)`
**» `User ID     :`** `{uuid}`
**» `Path Vless  :`** `vless `
**» `Path Dynamic:`** `http://BUG.COM/vless `
•━━━━━━━━━━━━•
**» Link TLS   : ** `{x[0]}`
•━━━━━━━━━━━━•
**» Link NTLS  :** `{x[1].replace(" ","")}`
•━━━━━━━━━━━━•
**» Link GRPC  :** `{x[2].replace(" ","")}`
•━━━━━━━━━━━━•
**» Format Openclash  :** https://{DOMAIN}:81/vless-{user}.txt
•━━━━━━━━━━━━•
**🗓️ Expired Until:** `{later}`
**🤖 @tau_samawa**
•━━━━━━━━━━━━•
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await addvless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#MEMBER VLESS
@bot.on(events.NewMessage(pattern=r"(?:.memvless|/memvless|memvless|/memvless@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'mem-vless'))
async def memvless(event):
	async def memvless_(event):
		cmd = 'bot-mem-vless'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
**Shows Users Vless**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await memvless_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#CEK VMESS
@bot.on(events.NewMessage(pattern=r"(?:.cekvless|/cekvless|cekvless|/cekvless@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cekvless(event):
	async def cekvless_(event):
		cmd = 'bot-cekvless'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```{z}```
**Shows Logged Vless**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cekvless_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#RENEW
@bot.on(events.NewMessage(pattern=r"(?:.renewvless|/renewvless|renewvless|/renewvless@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'renew-vless'))
async def renewvless(event):
	async def renewvless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vless/.vless.db | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ LIST RENEW USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**» Expired (Hari) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as pw2:
			await event.respond("**» Limit User (GB) :**")
			pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw2 = (await pw2).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**» Limit User (IP) :**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		cmd = f'printf "%s\n" "3" "{user}" "{exp}" "{pw2}" "{pw}" | m-vless | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Renewed ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renewvless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#LIMIT
@bot.on(events.NewMessage(pattern=r"(?:.limitvless|/limitvless|limitvless|/limitvless@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'limit-vless'))
async def limitvless(event):
	async def limitvless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vless/.vless.db | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ CHANGE LIMIT USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**» Limit User (IP) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**» Limit User (GB) :**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		cmd = f'printf "%s\n" "6" "{user}" "{exp}" "{pw}" | m-vless | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Change ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limitvless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#delete
@bot.on(events.NewMessage(pattern=r"(?:.delvless|/delvless|delvless|/delvless@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delvless(event):
	async def delvless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vless/.vless.db | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ LIST DELETE USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "2" "{user}" | m-vless | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Deleted ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delvless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.NewMessage(pattern=r"(?:.trialvless|/trialvless|trialvless|/trialvless@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trialvless(event):
	async def trialvless_(event):
		cmd =	f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "1" | bot-trialvless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(1))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
•━━━━━━━━━━━━•
**• Xray/Vless Account •**
•━━━━━━━━━━━━•
**» `Remarks     :`** `{remarks}`
**» `Host Server :`** `{DOMAIN}`
**» `Port DNS    :`** `443, 53`
**» `port TLS    :`** `443`
**» `Port NTLS   :`** `80`
**» `Port Grpc   :`** `443`
**» `NetWork     :`** `(WS) or (gRPC)`
**» `User ID     :`** `{uuid}`
**» `Path Vless  :`** `/vless `
**» `Path Dynamic:`** `http://BUG.COM/vless `
•━━━━━━━━━━━━•
**» Link TLS   : **
`{x[0]}`
•━━━━━━━━━━━━•
**» Link NTLS  :**
`{x[1].replace(" ","")}`
•━━━━━━━━━━━━•
**» Link GRPC  :**
`{x[2].replace(" ","")}`
•━━━━━━━━━━━━•
**» Link QR  :** `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${x[0]}`
•━━━━━━━━━━━━•
**🗓️ Expired Until:** `{later}`
**🤖 @tau_samawa**
•━━━━━━━━━━━━•
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trialvless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.NewMessage(pattern=r"(?:.vless|/vless|vless|/vless@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'vless'))
async def start(event):
	inline = [
[Button.inline(" ᴛʀɪᴀʟ ","trial-vless")],
[Button.inline(" ᴄʀᴇᴀᴛᴇ ","create-vless"),
Button.inline(" ᴄʜᴇᴄᴋ ","cek-vless"),
Button.inline(" ᴅᴇʟᴇᴛᴇ ","delete-vless")],
[Button.inline(" ʀᴇɴᴇᴡ ","renew-vless"),
Button.inline(" ᴍᴇᴍʙᴇʀ ","mem-vless"),
Button.inline(" ʟɪᴍɪᴛ ","limit-vless")],
[Button.inline("🔙ᴍᴀɪɴ ᴍᴇɴᴜ","menu")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")
		iisp = f" cat /etc/xray/isp"
		iisp = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
•━━━━━━━━━━━━•
**❖ ᴠʟᴇꜱꜱ ᴍᴀɴᴀɢᴇʀ ❖**
•━━━━━━━━━━━━•
**🔹 ꜱᴇʀᴠɪᴄᴇ:** `ᴠʟᴇꜱꜱ`
**🔹 ʜᴏꜱᴛɴᴀᴍᴇ/ɪᴘ :** `{DOMAIN}`
**🔹 ɪꜱᴘ:** `{z["isp"]}`
**🔹 ᴄᴏᴜɴᴛʀʏ :** `{city.strip()}`
**🔹 ᴠʟᴇꜱꜱ ᴀᴄᴄᴏᴜɴᴛ :** `{vls.strip()}`
•━━━━━━━━━━━━•
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
