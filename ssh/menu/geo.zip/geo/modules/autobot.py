from geo import *

#REBOOT 1 JAM
@bot.on(events.CallbackQuery(data=b'satujam'))
async def satujam(event):
	async def satujam_(event):
		cmd = f'printf "%s\n" "1" | autoreboot | sleep 5 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autoreboot Every 1 Hour ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobot")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await satujam_(event)
	else:
		await event.answer("Access Denied",alert=True)
		

#REBOOT 6
@bot.on(events.CallbackQuery(data=b'enamjam'))
async def enamjam(event):
	async def enamjam_(event):
		cmd = f'printf "%s\n" "2" | autoreboot | sleep 5 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autoreboot Every 6 Hour ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobot")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await enamjam_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#REBOOT 12
@bot.on(events.CallbackQuery(data=b'duabelasjam'))
async def duabelasjam(event):
	async def duabelasjam_(event):
		cmd = f'printf "%s\n" "3" | autoreboot | sleep 5 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autoreboot Every 12 Hour ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobot")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await duabelasjam_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#REBOOT 1 HARI
@bot.on(events.CallbackQuery(data=b'satuhari'))
async def satuhari(event):
	async def satuhari_(event):
		cmd = f'printf "%s\n" "4" | autoreboot | sleep 5 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autoreboot Every 1 Days ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobot")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await satuhari_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#REBOOT 1 MINGGU
@bot.on(events.CallbackQuery(data=b'satuminggu'))
async def satuminggu(event):
	async def satuminggu_(event):
		cmd = f'printf "%s\n" "5" | autoreboot | sleep 5 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autoreboot Every 1 Week ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobot")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await satuminggu_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#REBOOT 1 BULAN
@bot.on(events.CallbackQuery(data=b'satubulan'))
async def satubulan(event):
	async def satubulan_(event):
		cmd = f'printf "%s\n" "6" | autoreboot | sleep 5 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autoreboot Every 1 Month ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobot")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await satubulan_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#OFF AUTO REBOOT
@bot.on(events.CallbackQuery(data=b'offautoreboot'))
async def offautoreboot(event):
	async def offautoreboot_(event):
		cmd = f'printf "%s\n" "7" | autoreboot | sleep 5 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Deactivate Auto-Reboot ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobot")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await offautoreboot_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
@bot.on(events.CallbackQuery(data=b'infolog'))
async def infolog(event):
	async def infolog_(event):
		cmd = 'cat /root/log-reboot.txt'.strip()
		await event.edit("Processing...")
		time.sleep(1)
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""```{z}```
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await infolog_(event)
	else:
		await event.answer("Access Denied",alert=True)

#DELETE LOG REBOOT
@bot.on(events.CallbackQuery(data=b'deledlog'))
async def deledlog(event):
	async def deledlog_(event):
		cmd = f'printf "%s\n" "9" | autoreboot | sleep 5 | exit'
		time.sleep(0)
		await event.edit("`Processing... `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Delete Reboot Log ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","autobot")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await deledlog_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#MENU AUTOREBOOT
@bot.on(events.NewMessage(pattern=r"(?:.autobot|/autobot|autobot|/autobot@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'autobot'))
async def start(event):
	inline = [
[Button.inline(" ᴀꜰᴛᴇʀ 1 ʜᴏᴜʀ ","satujam")],
[Button.inline(" ᴀꜰᴛᴇʀ 6 ʜᴏᴜʀ","enamjam"),
Button.inline(" ᴀꜰᴛᴇʀ 12 ʜᴏᴜʀ","duabelasjam")],
[Button.inline(" ᴀꜰᴛᴇʀ 1 ᴅᴀʏs","satuhari")],
[Button.inline(" ᴀꜰᴛᴇʀ 1 ᴡᴇᴇᴋ ","satuminggu"),
Button.inline(" ᴀꜰᴛᴇʀ 1 ᴍᴏɴᴛʜ​","satubulan")],
[Button.inline(" ᴛᴜʀɴ ᴏꜰꜰ","offautoreboot")],
[Button.inline(" ᴅᴇʟᴇᴛᴇ ʟᴏɢ​","deledlog"),
Button.inline(" ʟᴏɢ ʀᴇʙᴏᴏᴛ​","infolog")],
[Button.inline("🔙ᴍᴀɪɴ ᴍᴇɴᴜ","setting")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")
		iisp = f" cat /etc/xray/isp"
		iisp = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
•━━━━━━━━━━━━•
**• ʀᴇʙᴏᴏᴛ ꜱᴇᴛᴛɪɴɢꜱ •**
•━━━━━━━━━━━━•
**🔹 ᴏꜱ   :** `{namaos.strip().replace('"','')}`
**🔹 ᴄᴏᴜɴᴛʀʏ :** `{city.strip()}`
**🔹 ʜᴏꜱᴛɴᴀᴍᴇ/ɪᴘ :** `{DOMAIN}`
**🔹 ©ɢᴇᴏ ᴘʀᴏᴊᴇᴄᴛ**
•━━━━━━━━━━━━•
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
