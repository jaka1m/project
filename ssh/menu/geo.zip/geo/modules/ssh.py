from geo import *
#DELETE SSH
@bot.on(events.NewMessage(pattern=r"(?:.delssh|/delssh|delssh|/delssh@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delssh(event):
	async def delssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/ssh/.ssh.db | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ LIST DELETE USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "2" "{user}" | m-sshws | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Deleted ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CRATE SSH
@bot.on(events.NewMessage(pattern=r"(?:.addssh|/addssh|addssh|/addssh@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def addssh(event):
	async def addssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond(f"""
**⚠️ ɴᴏ ꜱᴘᴀᴄᴇ**

**👉 ɪɴᴘᴜᴛ ʏᴏᴜʀ ᴜꜱᴇʀɴᴀᴍᴇ :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond(f"""
**⚠️ ɴᴏ ꜱᴘᴀᴄᴇ**

**👉 ɪɴᴘᴜᴛ ʏᴏᴜʀ ᴘᴀꜱꜱᴡᴏʀᴅ :**
""")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Expired (Day) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as pw2:
			await event.respond("**Limit User (IP) :**")
			pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw2 = (await pw2).raw_text
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" "{pw2}" | bot-addssh'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
•━━━━━━━━━━━━•
** • SSH OVPN Account •**
•━━━━━━━━━━━━•
**» `Username :`** `{user.strip()}`
**» `Password :`** `{pw.strip()}`
•━━━━━━━━━━━━•
**» `NS       :`** `{DNS}`
**» `Host     :`** `{DOMAIN}`
**» `Limit IP :`** `{pw2} IP`
•━━━━━━━━━━━━•
**  • Running On Port •**
•━━━━━━━━━━━━•
**» `OpenSSH  :`** `443,80,22`
**» `Dropbear :`** `443,109`
**» `WS HTTP  :`** `80,8080 `
**» `WS SSL   :`** `443`
**» `SSL/TLS  :`** `443`
**» `Ovpn SSL :`** `443`
**» `Ovpn TCP :`** `443,1194`
**» `Ovpn UDP :`** `2200`
**» `UDP      :`** `1-65535`
**» `Squid    :`** `8000`
**» `BadVPN   :`** `7100,7300,7300`
**» `Pubkey   :`** `{PUB}`
•━━━━━━━━━━━━•
**» Link Ovpn :** https://{DOMAIN}:81
•━━━━━━━━━━━━•
**» Save Link Account :** https://{DOMAIN}:81/ssh-{user.strip()}.txt
•━━━━━━━━━━━━•
** 🗓️ Expired Until:** {later}
** 🤖 @tau_samawa**
•━━━━━━━━━━━━•
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await addssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#MEMBER SSH
@bot.on(events.NewMessage(pattern=r"(?:.memssh|/memssh|memssh|/memssh@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def memssh(event):
	async def memssh_(event):
		cmd = 'bot-member-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
**Show All SSH User**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await memssh_(event)
	else:
		await event.answer("Access Denied",alert=True)

# TRIAL SSH
@bot.on(events.NewMessage(pattern=r"(?:.trialssh|/trialssh|trialssh|/trialssh@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trialssh(event):
	async def trialssh_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Expired (Minutes) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" {11} "{exp}" | m-sshws | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Created ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trialssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# CECK SSH
@bot.on(events.NewMessage(pattern=r"(?:.cekssh|/cekssh|cekssh|/cekssh@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def cekssh(event):
	async def cekssh_(event):
		cmd = 'bot-cekssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
**shows logged in users**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cekssh_(event)
	else:
		await event.answer("Access Denied",alert=True)

#RENEW SSH
@bot.on(events.NewMessage(pattern=r"(?:.renewssh|/renewssh|renewssh|/renewssh@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def renewssh(event):
	async def renewssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/ssh/.ssh.db | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ LIST RENEW USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**» Expired (Hari) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as exp2:
			await event.respond("**» Limit User (IP) :**")
			exp2 = exp2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp2 = (await exp2).raw_text
		cmd = f'printf "%s\n" "3" "{user}" "{exp}" "{exp2}" | m-sshws | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Renewed ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renewssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#LIMIT SSH
@bot.on(events.NewMessage(pattern=r"(?:.limitssh|/limitssh|limitssh|/limitssh@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'limit-ssh'))
async def limitssh(event):
	async def limitssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/ssh/.ssh.db | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ CHANGE LIMIT USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**» Limit User (IP) :**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "6" "{user}" "{exp}" | m-sshws | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Change Limit ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limitssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#UNLOCK
@bot.on(events.NewMessage(pattern=r"(?:.unlockssh|/unlockssh|unlockssh|/unlockssh@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'unlock-ssh'))
async def unlockssh(event):
	async def unlockssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/ssh/.ssh.db | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ LIST USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "8" "{user}" | m-sshws | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Unlock ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlockssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#LOCK
@bot.on(events.NewMessage(pattern=r"(?:.lockssh|/lockssh|lockssh|/lockssh@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'lock-ssh'))
async def lockssh(event):
	async def lockssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/ssh/.ssh.db | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.respond(f"""
**⚡ LIST USER**
{z}
**👉 Select Your Number :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "7" "{user}" | m-sshws | sleep 3 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Lock ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lockssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.NewMessage(pattern=r"(?:.ssh|/ssh|ssh|/ssh@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'ssh'))
async def start(event):
	inline = [
[Button.inline(" ᴛʀɪᴀʟ ","trial-ssh")],
[Button.inline(" ᴄʀᴇᴀᴛᴇ ","create-ssh"),
Button.inline(" ᴅᴇʟᴇᴛᴇ ","delete-ssh"),
Button.inline(" ᴄᴇᴄᴋ ","login-ssh")],
[Button.inline(" ᴍᴇᴍʙᴇʀ ","show-ssh"),
Button.inline(" ʀᴇɴᴇᴡ ","renew-ssh"),
Button.inline(" ᴀᴜᴛᴏᴋɪʟʟ ","killer")],
[Button.inline(" ʟɪᴍɪᴛ ","limit-ssh"),
Button.inline(" ᴜɴʟᴏᴄᴋ  ","unlock-ssh"),
Button.inline(" ʟᴏᴄᴋ ","lock-ssh")],
[Button.inline("🔙ᴍᴀɪɴ ᴍᴇɴᴜ","menu")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")
		iisp = f" cat /etc/xray/isp"
		iisp = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
•━━━━━━━━━━━━•
**❖ ꜱꜱʜ ᴏᴠᴘɴ ᴍᴀɴᴀɢᴇʀ ❖**
•━━━━━━━━━━━━•
**🔹 ꜱᴇʀᴠɪᴄᴇ:** `ꜱꜱʜ`
**🔹 ʜᴏꜱᴛɴᴀᴍᴇ/ɪᴘ :** `{DOMAIN}`
**🔹 ɪꜱᴘ:** `{z["isp"]}`
**🔹 ᴄᴏᴜɴᴛʀʏ :** `{city.strip()}`
**🔹 ꜱꜱʜ ᴀᴄᴄᴏᴜɴᴛ :** `{ssh.strip()}`
•━━━━━━━━━━━━•
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
