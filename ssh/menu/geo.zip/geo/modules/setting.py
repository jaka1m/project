from geo import *

@bot.on(events.NewMessage(pattern=r"(?:.reboot|/reboot|reboot|/reboot@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'reboot'))
async def reboot(event):
	async def reboot_(event):
		cmd = f'reboot'
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Restart Service Server...`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
**» REBOOT SERVER**
**» 🤖©ɢᴇᴏ ᴘʀᴏᴊᴇᴄᴛ**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await reboot_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'clear'))
async def clear(event):
	async def clear_(event):
		cmd = f'printf "%s\n" "11" "12" | settings | sleep 4 | exit'
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Successfully Clear Log ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await clear_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#SPEEDTEST
@bot.on(events.NewMessage(pattern=r"(?:.restart|/restart|restart|/restart@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'resx'))
async def restart(event):
	async def restart_(event):
		cmd = f'systemctl restart xray | systemctl restart nginx | systemctl restart haproxy | systemctl restart server | systemctl restart client'
		subprocess.check_output(cmd, shell=True)
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Restart Service Server...`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit(f"""
```Processing... 100%\n█████████████████████████ ```
**» Restarting Service Done**
**» 🤖©ɢᴇᴏ ᴘʀᴏᴊᴇᴄᴛ**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await restart_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#SPEEDTEST
@bot.on(events.NewMessage(pattern=r"(?:.speedtest|/speedtest|speedtest|/speedtest@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
	async def speedtest_(event):
		cmd = 'speedtest-cli --share'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		time.sleep(0)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.respond(f"""
**
{z}
**
**» 🤖©ɢᴇᴏ ᴘʀᴏᴊᴇᴄᴛ**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await speedtest_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.NewMessage(pattern=r"(?:.backup|/backup|backup|/backup@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
	async def backup_(event):
		async with bot.conversation(chat) as pw:
			await event.respond("**» Token Telegram :**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as pw2:
			await event.respond("**» ID Telegram :**")
			pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw2 = (await pw2).raw_text
		cmd = f'printf "%s\n" "4" "{pw}" "{pw2}" | settings | sleep 6 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Backup Account ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await backup_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'abackup'))
async def abackup(event):
	async def abackup_(event):
		cmd = f'printf "%s\n" "3" "1" | settings | sleep 10 | exit'
		time.sleep(0)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)		
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.respond(f"""
**» Succes**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await abackup_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#BAKUP LINK
@bot.on(events.NewMessage(pattern=r"(?:.link|/link|link|/link@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'restore'))
async def link(event):
	async def link_(event):
		async with bot.conversation(chat) as pw2:
			await event.respond("**» Link Backup :**")
			pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw2 = (await pw2).raw_text
		cmd = f'printf "%s\n" "5" "2" "{pw2}" | settings | sleep 15 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Restore Account ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await link_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#BAKUP TOKEN
@bot.on(events.NewMessage(pattern=r"(?:.token|/token|token|/token@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'restoree'))
async def token(event):
	async def token_(event):
		async with bot.conversation(chat) as pw2:
			await event.respond("**» Token Telegram :**")
			pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw2 = (await pw2).raw_text
		cmd = f'printf "%s\n" "5" "1" "{pw2}" | settings | sleep 6 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» Successfully Restore Account ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await token_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
	async def backers_(event):
		inline = [
[Button.inline(" ʙᴀᴄᴋᴜᴘ","backup")],
[Button.inline(" ꜱᴇᴛᴛ ᴀᴜᴛᴏ ʙᴄᴋᴘ","autobckp"),
Button.inline(" ʀᴇꜱᴛᴏʀᴇ ʟɪɴᴋ","restore")],
[Button.inline(" ʀᴇꜱᴛᴏʀᴇ ᴛᴏᴋᴇɴ","restoree"),
Button.inline("🔙ᴍᴀɪɴ ᴍᴇɴᴜ","setting")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
•━━━━━━━━━━━━•
**• ʙᴀᴄᴋᴜᴘ & ʀᴇꜱᴛᴏʀᴇ •**
•━━━━━━━━━━━━•
**🔹 ʜᴏꜱᴛɴᴀᴍᴇ/ɪᴘ:** `{DOMAIN}`
**🔹 ɪꜱᴘ:** `{z["isp"]}`
**🔹 ᴄᴏᴜɴᴛʀʏ:** `{z["country"]}`
**🔹 ©ɢᴇᴏ ᴘʀᴏᴊᴇᴄᴛ**
•━━━━━━━━━━━━•
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await backers_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.NewMessage(pattern=r"(?:.setting|/setting|setting|/setting@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'setting'))
async def start(event):
	inline = [
[Button.inline("ʙᴀᴄᴋᴜᴘ & ʀᴇsᴛᴏʀᴇ","backer")],
[Button.inline("ꜱᴘᴇᴇᴅᴛᴇꜱᴛ","speedtest"),
Button.inline("ʀᴇʙᴏᴏᴛ","reboot")],
[Button.inline("ᴀᴜᴛᴏʀᴇʙᴏᴏᴛ","autobot"),
Button.inline("ʀᴇꜱᴛᴀʀᴛ","resx")],
[Button.inline("ᴄʟᴇᴀʀ ʟᴏɢ","clear"),
Button.inline("🔙ᴍᴀɪɴ ᴍᴇɴᴜ","menu")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
•━━━━━━━━━━━━•
** • ᴏᴛʜᴇʀ ꜱᴇᴛᴛɪɴɢꜱ •**
•━━━━━━━━━━━━•
**🔹 ᴏꜱ   :** `{namaos.strip().replace('"','')}`
**🔹 ᴄᴏᴜɴᴛʀʏ :** `{city.strip()}`
**🔹 ʜᴏꜱᴛɴᴀᴍᴇ/ɪᴘ :** `{DOMAIN}`
**🔹 ©ɢᴇᴏ ᴘʀᴏᴊᴇᴄᴛ**
•━━━━━━━━━━━━•
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
