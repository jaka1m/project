from geo import *

#AUTO KILL 5 MENIT
@bot.on(events.CallbackQuery(data=b'lima-menit'))
async def lima_menit(event):
	async def lima_menit_(event):
		cmd = f'printf "%s\n" "10" "1" | m-sshws | sleep 6 | exit'
		time.sleep(0)
		await event.edit("`Processing . . . `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autokill Every 5 Minutes ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","killer")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lima_menit_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#AUTO KILL 10 MENIT
@bot.on(events.CallbackQuery(data=b'sepuluh-menit'))
async def sepuluh_menit(event):
	async def sepuluh_menit_(event):
		cmd = f'printf "%s\n" "10" "2" | m-sshws | sleep 6 | exit'
		time.sleep(0)
		await event.edit("`Processing . . . `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autokill Every 10 Minutes ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","killer")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await sepuluh_menit_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
#AUTO KILL 15 MENIT
@bot.on(events.CallbackQuery(data=b'limabelas-menit'))
async def limabelas_menit(event):
	async def limabelas_menit_(event):
		cmd = f'printf "%s\n" "10" "3" | m-sshws | sleep 6 | exit'
		time.sleep(0)
		await event.edit("`Processing . . . `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Autokill Every 15 Minutes ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","killer")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limabelas_menit_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
# OFF AUTO KILL
@bot.on(events.CallbackQuery(data=b'tur-off'))
async def tur_off(event):
	async def tur_off_(event):
		cmd = f'printf "%s\n" "10" "4" | m-sshws | sleep 10 | exit'
		time.sleep(0)
		await event.edit("`Processing . . . `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**» Turn Off Autokill ✅**
""",buttons=[[Button.inline("‹ Main Menu ›","killer")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await tur_off_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
@bot.on(events.NewMessage(pattern=r"(?:.killer|/killer|killer|/killer@geo_vpn_bot)$"))
@bot.on(events.CallbackQuery(data=b'killer'))
async def start(event):
	inline = [
[Button.inline(" ᴀꜰᴛᴇʀ 5 ᴍɪɴᴜᴛᴇs ","lima-menit")],
[Button.inline(" ᴀꜰᴛᴇʀ 10 ᴍɪɴᴜᴛᴇs","sepuluh-menit"),
Button.inline(" ᴀꜰᴛᴇʀ 15 ᴍɪɴᴜᴛᴇs","limabelas-menit")],
[Button.inline(" ᴛᴜʀɴ ᴏꜰꜰ","tur-off"),
Button.inline("🔙ᴍᴀɪɴ ᴍᴇɴᴜ","ssh")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")
		iisp = f" cat /etc/xray/isp"
		iisp = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
•━━━━━━━━━━━━•
**• ꜱᴇᴛᴛɪɴɢ ᴀᴜᴛᴏ ᴋɪʟʟ •**
•━━━━━━━━━━━━•
**🔹 ᴏꜱ     :** `{namaos.strip().replace('"','')}`
**🔹 ᴄᴏᴜɴᴛʀʏ :** `{city.strip()}`
**🔹 ʜᴏꜱᴛɴᴀᴍᴇ/ɪᴘ :** `{DOMAIN}`
**🔹 ©ɢᴇᴏ ᴘʀᴏᴊᴇᴄᴛ**
•━━━━━━━━━━━━•
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
